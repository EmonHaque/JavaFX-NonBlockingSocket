import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.ObservableList;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;

public class Receiver extends Thread{
    SocketChannel socket;
    Selector selector;
    ObservableList<String> messages;
    BooleanProperty isConnected;

    public Receiver(ObservableList<String> messages) {
        isConnected = new SimpleBooleanProperty(false);
        this.messages = messages;
        try {
            selector = Selector.open();
            socket = SocketChannel.open();
            socket.configureBlocking(false);
            socket.register(selector, SelectionKey.OP_CONNECT);
            socket.connect(new InetSocketAddress(Constants.HOST, Constants.PORT_SEND));
            while (!socket.finishConnect()){
                Thread.sleep(5);
                // return if it takes long
            }
            socket.register(selector, SelectionKey.OP_READ);
            start();
            isConnected.set(true);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        while (!isInterrupted()){
            try {
                selector.select();
                var buffer = ByteBuffer.allocate(Constants.MESSAGE_SIZE);
                int read = socket.read(buffer);
                if(read == -1 || isInterrupted()) {
                    isConnected.set(false);
                    break;
                }
                Platform.runLater(() -> messages.add(new String(buffer.array()).trim()));
            } catch (IOException e) {
                break;
                //e.printStackTrace();
            }
        }
        try {
            selector.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Receiver Read Thread closing");
    }
    public void close(){
        interrupt();
    }
}
