import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedSelectorException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.concurrent.BlockingQueue;

public class Sender extends Thread{
    SocketChannel socket;
    Selector selector;
    BlockingQueue<String> messages;
    Thread readThread;

    public Sender(BlockingQueue<String> messages) {
        this.messages = messages;
        try {
            selector = Selector.open();
            socket = SocketChannel.open();
            socket.configureBlocking(false);
            socket.register(selector, SelectionKey.OP_CONNECT);
            socket.connect(new InetSocketAddress(Constants.HOST, Constants.PORT_RECEIVE));
            while (!socket.finishConnect()){
                Thread.sleep(5);
                // return if it takes long
            }
            socket.register(selector, SelectionKey.OP_READ);
            readThread = new Thread(this::read);
            readThread.start();
            start();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    void read(){
        var buffer = ByteBuffer.allocate(1);
        while (!isInterrupted()){
            try {
                selector.select();
                int read = socket.read(buffer);
                if(read == -1) close();
            } catch (IOException | ClosedSelectorException e) {
                close();
                //e.printStackTrace();
            }
        }
        System.out.println("Sender Read Thread closing");
    }
    @Override
    public void run() {
        while (!isInterrupted()){
            try {
                var msg = messages.take();
                var buffer = ByteBuffer.wrap(msg.getBytes());
                socket.write(buffer);
            } catch (InterruptedException | IOException e) {
                break;
                //e.printStackTrace();
            }
        }
        try {
            selector.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Sender Write Thread closing");
    }
    public void close(){
        interrupt();
        readThread.interrupt();
    }
}
