import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class App extends Application {
    Button connect, disconnect, send;
    TextField textBox;
    ListView<String> listView;
    BlockingQueue<String> sendQueue;
    ObservableList<String> inbox;
    Sender sender;
    Receiver receiver;

    @Override
    public void init() throws Exception {
        super.init();
        connect = new Button("Connect");
        disconnect = new Button("Disconnect");
        disconnect.setDisable(true);
        send = new Button("Send");
        textBox = new TextField();
        inbox = FXCollections.observableArrayList();
        listView = new ListView<>(inbox);
        sendQueue = new ArrayBlockingQueue<>(1000);

        connect.setOnAction(this::connect);
        send.setOnAction(this::sendData);
        disconnect.setOnAction(this::disconnect);
    }

    @Override
    public void start(Stage stage) throws Exception {
        var leftBox = new VBox(connect, disconnect);
        leftBox.setSpacing(10);
        var bottomBox = new HBox(textBox, send);
        HBox.setHgrow(textBox, Priority.ALWAYS);
        bottomBox.setSpacing(10);
        var border = new BorderPane();
        border.setLeft(leftBox);
        border.setCenter(listView);
        border.setBottom(bottomBox);
        BorderPane.setMargin(leftBox, new Insets(5));
        BorderPane.setMargin(bottomBox, new Insets(5));
        BorderPane.setMargin(listView, new Insets(5, 5, 0, 0));
        stage.setScene(new Scene(border, 480,300));
        stage.setTitle("Client");
        stage.show();
    }

    @Override
    public void stop() throws Exception {
        disconnect(null);
        super.stop();
    }

    void connect(ActionEvent e){
        sender = new Sender(sendQueue);
        receiver = new Receiver(inbox);
        connect.disableProperty().bind(receiver.isConnected);
        disconnect.disableProperty().bind(receiver.isConnected.not());
    }
    void sendData(ActionEvent e){
        sendQueue.add(textBox.getText());
        textBox.clear();
    }
    void disconnect(ActionEvent e){
        sender.close();
        receiver.close();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
