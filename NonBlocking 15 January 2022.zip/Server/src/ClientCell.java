import javafx.scene.control.ListCell;

import java.io.IOException;
import java.nio.channels.SocketChannel;

public class ClientCell extends ListCell<SocketChannel> {
    @Override
    protected void updateItem(SocketChannel item, boolean empty) {
        super.updateItem(item, empty);
        if(item == null || empty) setText(null);
        else {
            try {
                var address = item.getRemoteAddress().toString().substring(1);
                setText(address);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
