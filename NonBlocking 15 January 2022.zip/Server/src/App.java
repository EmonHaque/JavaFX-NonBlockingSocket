import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.nio.channels.SocketChannel;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class App extends Application {
    Button start, stop;
    ListView<SocketChannel> receiverView, senderView;
    ObservableList<SocketChannel> receivers, senders;
    BlockingQueue<String> messageQueue;
    ReadChannel reader;
    WriteChannel writer;

    @Override
    public void init() throws Exception {
        super.init();
        start = new Button("Start");
        stop = new Button("Stop");
        receivers = FXCollections.observableArrayList();
        senders = FXCollections.observableArrayList();
        receiverView = new ListView<>(receivers);
        senderView = new ListView<>(senders);
        receiverView.setCellFactory(v -> new ClientCell());
        senderView.setCellFactory(v -> new ClientCell());
        messageQueue = new ArrayBlockingQueue<>(1000);

        start.setOnAction(this::start);
        stop.setOnAction(this::stop);
        stop.setDisable(true);
    }
    @Override
    public void start(Stage stage) throws Exception {
        var topBox = new HBox(start, stop);
        var bottomBox = new HBox(receiverView, senderView);
        var content = new VBox(topBox, bottomBox);
        topBox.setSpacing(10);
        bottomBox.setSpacing(10);
        content.setSpacing(10);
        topBox.setAlignment(Pos.CENTER);
        bottomBox.setAlignment(Pos.CENTER);
        VBox.setVgrow(bottomBox, Priority.ALWAYS);
        VBox.setMargin(bottomBox, new Insets(0,0,10,0));
        stage.setScene(new Scene(content, 480, 300));
        stage.setTitle("Server");
        stage.show();
    }
    @Override
    public void stop() throws Exception {
        super.stop();
        stop(null);
    }
    void start(ActionEvent e){
        reader = new ReadChannel(Constants.PORT_RECEIVE, receivers, messageQueue);
        writer = new WriteChannel(Constants.PORT_SEND, senders, messageQueue);
        start.setDisable(true);
        stop.setDisable(false);
    }
    void stop(ActionEvent e){
        if(reader != null){
            reader.close();
            writer.close();
        }
        start.setDisable(false);
        stop.setDisable(true);
    }
    public static void main(String[] args) {
        launch(args);
    }
}
