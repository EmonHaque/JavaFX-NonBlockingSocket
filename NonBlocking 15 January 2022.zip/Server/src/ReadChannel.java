import javafx.application.Platform;
import javafx.collections.ObservableList;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.concurrent.BlockingQueue;

public class ReadChannel extends Thread{
    ServerSocketChannel socket;
    Selector acceptor, reader;
    ObservableList<SocketChannel> clientList;
    BlockingQueue<String> queue;
    Thread readerThread;

    public ReadChannel(int port, ObservableList<SocketChannel> clientList, BlockingQueue<String> queue){
        this.clientList = clientList;
        this.queue = queue;
        try {
            acceptor = Selector.open();
            reader = Selector.open();
            socket = ServerSocketChannel.open();
            socket.configureBlocking(false);
            socket.bind(new InetSocketAddress(Constants.HOST, port), 1000);
            socket.register(acceptor, SelectionKey.OP_ACCEPT);

            readerThread = new Thread(this::read);
            readerThread.start();
            start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void run() {
        while (!isInterrupted()){
            try {
                acceptor.select();
                var iterator = acceptor.selectedKeys().iterator();
                while (iterator.hasNext()){
                    var key = iterator.next();
                    iterator.remove();
                    if(!key.isValid()) continue;
                    var client = socket.accept();

                    client.configureBlocking(false);
                    client.register(reader, SelectionKey.OP_READ);
                    Platform.runLater(() -> clientList.add(client));
                }
                spank();
            } catch (IOException e) {
                e.printStackTrace();
            }
            catch (ClosedSelectorException e){
                break;
            }
        }
        System.out.println("ReadChannel Accept Thread closing");
    }
    private void read(){
        while (!isInterrupted()){
            try {
                reader.select();
                var iterator = reader.selectedKeys().iterator();
                while (iterator.hasNext()){
                    var key = iterator.next();
                    iterator.remove();
                    var channel = (SocketChannel) key.channel();
                    var buffer = ByteBuffer.allocate(Constants.MESSAGE_SIZE);
                    int read = channel.read(buffer);
                    if(read != -1) queue.add(new String(buffer.array()).trim());
                    else {
                        //key.cancel();
                        channel.close();
                        Platform.runLater(() -> clientList.remove(channel));
                    }
                }
            } catch (IOException | ClosedSelectorException e) {
                break;
                //e.printStackTrace();
            }
        }
        System.out.println("ReadChannel Read Thread closing");
    }
    private void spank(){
        reader.wakeup();
    }
    public void close(){
        try {
            acceptor.close();
            reader.close();
            interrupt();
            for(var client : clientList) client.close();
            Platform.runLater(() -> clientList.clear());
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
