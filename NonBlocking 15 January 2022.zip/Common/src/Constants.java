public class Constants {
    public static final String HOST = "127.0.0.1";
    public static final int PORT_SEND = 5555;
    public static final int PORT_RECEIVE = 4444;
    public static final int MESSAGE_SIZE = 256;
}
