import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

import java.io.IOException;
import java.lang.reflect.WildcardType;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedSelectorException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.concurrent.BlockingQueue;

public class Sender extends Thread{
    SocketChannel socket;
    Selector selector;
    BlockingQueue<String> messages;
    BooleanProperty isClosed;
    Thread readThread;

    public Sender(BlockingQueue<String> messages) {
        isClosed = new SimpleBooleanProperty();
        this.messages = messages;
        try {
            selector = Selector.open();
            socket = SocketChannel.open();
            socket.configureBlocking(false);
            socket.register(selector, SelectionKey.OP_CONNECT);
            socket.connect(new InetSocketAddress(Constants.HOST, Constants.PORT_RECEIVE));
            while (!socket.finishConnect()){
                Thread.sleep(5);
                // return if it takes long
            }
            socket.register(selector, SelectionKey.OP_READ);
            readThread = new Thread(this::read);
            readThread.start();
            start();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    void read(){
        var buffer = ByteBuffer.allocate(1);
        while (!isInterrupted()){
            try {
                selector.select();
                int read = socket.read(buffer);
                if(read == -1){
                    System.out.println("read -1");
                    close();
                }
            } catch (IOException | ClosedSelectorException e) {
                close();
                //e.printStackTrace();
            }
        }
        System.out.println("Client Sender read closing");
    }
    @Override
    public void run() {
        while (!isInterrupted()){
            try {
                var msg = messages.take();
                var buffer = ByteBuffer.wrap(msg.getBytes());
                System.out.println("Writing " + msg);
                socket.write(buffer);
            } catch (InterruptedException | IOException e) {
                break;
                //e.printStackTrace();
            }
        }
        try {
            selector.close();
            socket.close();
            socket = null;
            isClosed.set(true);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Client Sender closing");
    }

    public void close(){
        interrupt();
        readThread.interrupt();
    }
}
