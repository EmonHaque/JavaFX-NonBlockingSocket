import javafx.application.Platform;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;

public class Receiver extends Thread{
    SocketChannel socket;
    Selector selector;
    ObservableList<String> messages;

    public Receiver(ObservableList<String> messages) {
        this.messages = messages;
        try {
            selector = Selector.open();
            socket = SocketChannel.open();
            socket.configureBlocking(false);
            socket.register(selector, SelectionKey.OP_CONNECT);
            socket.connect(new InetSocketAddress(Constants.HOST, Constants.PORT_SEND));
            while (!socket.finishConnect()){
                Thread.sleep(5);
                // return if it takes long
            }
            socket.register(selector, SelectionKey.OP_READ);
            start();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (!isInterrupted()){
            try {
                selector.select();
                var buffer = ByteBuffer.allocate(Constants.MESSAGE_SIZE);
                int read = socket.read(buffer);
                if(read == -1) break;
                Platform.runLater(() -> messages.add(new String(buffer.array()).trim()));
            } catch (IOException e) {
                break;
                //e.printStackTrace();
            }
        }
        try {
            selector.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Client Receiver closing");
    }
    public void close(){
        interrupt();
    }
}
