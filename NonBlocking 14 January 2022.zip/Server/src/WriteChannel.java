import javafx.application.Platform;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.concurrent.BlockingQueue;

public class WriteChannel extends Thread {
    ServerSocketChannel socket;
    Selector acceptor, reader, writer;
    ObservableList<SocketChannel> clientList;
    BlockingQueue<String> queue;
    Thread readerThread, writerThread;

    public WriteChannel(int port, ObservableList<SocketChannel> clientList, BlockingQueue<String> queue){
        this.clientList = clientList;
        this.queue = queue;
        try {
            acceptor = Selector.open();
            reader = Selector.open();
            writer = Selector.open();
            socket = ServerSocketChannel.open();
            socket.configureBlocking(false);
            socket.bind(new InetSocketAddress(Constants.HOST, port), 1000);
            socket.register(acceptor, SelectionKey.OP_ACCEPT);

            readerThread = new Thread(this::read);
            writerThread = new Thread(this::write);
            readerThread.start();
            writerThread.start();
            start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (!isInterrupted()){
            try {
                acceptor.select();
                var keys = acceptor.selectedKeys();
                for(var key : keys){
                    if(!key.isValid()) continue;
                    var client = socket.accept();
                    client.configureBlocking(false);
                    client.register(reader, SelectionKey.OP_READ);
                    client.register(writer, SelectionKey.OP_WRITE);
                    Platform.runLater(() -> clientList.add(client));
                }
                keys.clear();
                reader.wakeup();
                writer.wakeup();
            } catch (IOException e) {
                e.printStackTrace();
            }
            catch (ClosedSelectorException e){
                break;
            }
        }
        System.out.println("WriteChannel accept closing");
    }
    private void read(){
        while (!isInterrupted()){
            try {
                //System.out.println("WriteChannel reading");
                reader.select();
                var keys = reader.selectedKeys();
                for (var key : keys) {
                    var channel = (SocketChannel) key.channel();
                    var buffer = ByteBuffer.allocate(Constants.MESSAGE_SIZE);
                    int read = channel.read(buffer);
                    if(read != -1) queue.add(new String(buffer.array()).trim());
                    else {
                        channel.close();
                        Platform.runLater(() -> clientList.remove(channel));
                    }
                }
                keys.clear();
            } catch (IOException | ClosedSelectorException e) {
                break;
                //e.printStackTrace();
            }
        }
        System.out.println("WriteChannel read closing");
    }
    private void write(){
        while (!isInterrupted()){
            try {
                //System.out.println("WriteChannel writing");
                var msg = queue.take();
                writer.select();
                var keys = writer.selectedKeys();
                for(var key : keys){
                    if(!key.isValid()) continue;
                    var client = (SocketChannel)key.channel();
                    client.write(ByteBuffer.wrap(msg.getBytes()));
                }
                keys.clear();
            } catch (IOException e) {
                e.printStackTrace();
            }
            catch (InterruptedException | ClosedSelectorException e){
                break;
            }
        }
        System.out.println("WriteChannel write closing");
    }
    public void close(){
        try {
            acceptor.close();
            reader.close();
            writer.close();
            interrupt();
            writerThread.interrupt();
            for(var client : clientList) client.close();
            Platform.runLater(() -> clientList.clear());
            socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
